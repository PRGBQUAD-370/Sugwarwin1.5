Sugwarwin1.5 non safety version is very dangerous and corrupts the masterboot record making the computer become in a unusable state until windows is reinstalled.

Credit's to prgbquad-370 for creating this